import sys
import csv
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import datetime

array = []

closing_prices = []

moving_averages = []


def read_from_file(filename):
    with open(filename) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            if line_count == 0:
                line_count += 1
            else:
                temp = [datetime.datetime.strptime(row[0], "%Y-%m-%d").date(), float(row[1]), float(row[2]),
                        float(row[3]), float(row[4]), float(row[5]), int(row[6])]
                array.append(temp)
                line_count += 1


def plot_variation(start, end):
    arr = array
    start_index = arr.index([row for row in arr if row[0] >= start][0])
    end_index = arr.index([row for row in arr if row[0] >= end][0])
    arr = arr[start_index:end_index]
    dates = [row[0] for row in arr]
    for row in arr:
        closing_prices.append(row[4])
    fig, ax = plt.subplots()
    ax.plot(dates, closing_prices)
    ax.set_ylabel('Closing Pice')
    ax.set_xlabel('Date (Y-M-D)')
    ax.set_title('Variation of Closing Prices')

    datemin = dates[0]
    datemax = dates[-1]
    ax.set_xlim(datemin, datemax)
    ax.format_xdata = mdates.DateFormatter('%Y-%m')
    ax.format_ydata = lambda x: f'${x:.2f}'  # Format the price.
    ax.grid(True)
    fig.autofmt_xdate()

    plt.show()


def moving_average(start, end):
    arr = array
    start_index = arr.index([row for row in arr if row[0] >= start][0])
    end_index = arr.index([row for row in arr if row[0] >= end][0])
    window_size = 4
    if (start_index - window_size + 1) < 0:
        zeros = [0] * (window_size - 1 - start_index)
        arr = arr[:end_index]
        dates = zeros + [row[0] for row in arr]
        close = zeros + [row[4] for row in arr]
    else:
        arr = arr[start_index - window_size + 1:end_index]
        dates = [row[0] for row in arr]
        close = [row[4] for row in arr]
    i = 0
    new_dates = dates[3:]
    while i < len(close) - 4 + 1:
        this_window = close[i: i + window_size]
        window_average = sum(this_window) / window_size
        moving_averages.append(window_average)
        i += 1

    fig, ax = plt.subplots()
    ax.plot(new_dates, moving_averages)
    ax.set_ylabel('Moving Average')
    ax.set_xlabel('Date (Y-M-D)')
    ax.set_title('Moving Averages of Closing Prices')

    datemin = new_dates[0]
    datemax = new_dates[-1]
    ax.set_xlim(datemin, datemax)
    ax.format_xdata = mdates.DateFormatter('%Y-%m')
    ax.format_ydata = lambda x: f'${x:.2f}'
    ax.grid(True)
    fig.autofmt_xdate()

    plt.show()


def calculate_values():
    mean_close = np.mean(closing_prices)
    std_close = np.std(closing_prices)
    rms_close = np.sqrt(mean_close * mean_close + std_close * std_close)
    print("Variation mean: " + "{:.2f}".format(mean_close))
    print("Variation standard deviation: " + "{:.2f}".format(std_close))
    print("Variation RMS: " + "{:.2f}".format(rms_close))
    mean_mov_avg = np.mean(moving_averages)
    std_mov_avg = np.std(moving_averages)
    rms_mov_avg = np.sqrt(mean_mov_avg * mean_mov_avg + std_mov_avg * std_mov_avg)
    print("Moving average mean: " + "{:.2f}".format(mean_mov_avg))
    print("Moving average standard deviation: " + "{:.2f}".format(std_mov_avg))
    print("Moving average RMS: " + "{:.2f}".format(rms_mov_avg))


if __name__ == '__main__':
    n = len(sys.argv)
    read_from_file(sys.argv[1])
    if n == 4:
        start_date = datetime.datetime.strptime(sys.argv[2], "%Y-%m-%d").date()
        end_date = datetime.datetime.strptime(sys.argv[3], "%Y-%m-%d").date()
    if n == 2:
        start_date = array[0][0]
        end_date = array[-1][0]
    plot_variation(start_date, end_date)
    moving_average(start_date, end_date)
    calculate_values()
