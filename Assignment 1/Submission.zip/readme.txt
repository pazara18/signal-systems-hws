Program has 2 running modes: Set intervals and all data

Set intervals mode takes csv name, start date, end date as command line argument in that order.

All data mode takes csv name as argument.

The program outputs 2 charts: variation of closing price and moving average with 4 taps.

The program also outputs average, standard deviation and root mean square values of drawn charts to the command line. 