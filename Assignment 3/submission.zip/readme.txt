Script first generates magnitude-phase response plots.
Then, it plots y(t) and x(t) for the first 2 seconds.
Then, it prints H(z) to the console.
Then, it plots output signal of the discrete time filter in d).
Then, it prints absolute mean (|part c - part e| / 1000) to the console.