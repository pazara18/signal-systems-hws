PartB&PartC.py
	-This file creates BPF.wav and BSP.wav files from filename hardcoded as a variable.
	-It has no GUI.
	-It uses f_c = 1700 Hz and BW = 1300/1700 i.e. f_cl = 400 Hz and f_ch = 3000 Hz.
PartD.py
	-When run it opens a GUI window.
	-This window has a textbox for browsing files to select .wav files, 2 horizontal
	sliders for f_c and BW and 2 radioboxes to select between BPF and BSP.
	-Pressing the filter button will generate filtered data.
	-Pressing play will play the filtered data.
	-When playing play button turns into stop and pressing it will stop the music.
	-Pressing save will save last filtered data stream into a fileB.wav file.
